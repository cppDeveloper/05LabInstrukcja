package com.example.a5labinstrukcja;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();
        final SensorManager sm = (SensorManager)getSystemService(SENSOR_SERVICE);
        boolean enabled = !sm.getSensorList(Sensor.TYPE_LIGHT).isEmpty();
        TextView tv = findViewById(R.id.lightinfo);
        String status = "Sensor światła: " + (enabled ? "tak" : "nie");
        tv.setText(status);
        tv.setTextColor(enabled ? Color.GREEN : Color.RED);
        findViewById(R.id.ASensorButton).setEnabled(enabled);

        enabled = !sm.getSensorList(Sensor.TYPE_ACCELEROMETER).isEmpty();
        tv = findViewById(R.id.accelinfo);
        status = "Sensor akceleracji: " + (enabled ? "tak" : "nie");
        tv.setText(status);
        tv.setTextColor(enabled ? Color.GREEN : Color.RED);
        findViewById(R.id.accelButton).setEnabled(enabled);

        final LocationManager lm =(LocationManager) getSystemService(LOCATION_SERVICE);
        enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        tv = findViewById(R.id.gpsinfo);
        status = "Sensor Gps: " + (enabled ? "tak" : "nie");
        tv.setText(status);
        tv.setTextColor(enabled ? Color.GREEN : Color.RED);
        findViewById(R.id.button_gps).setEnabled(enabled);

    }
    public final void startAktywnosc(final View v)
    {
        Intent in;
        if(v.getId() == R.id.button_gps)
            in = new Intent(this,GPS.class);
        else
        {
            in = new Intent(this, ASensor.class);
            if(v.getId() == R.id.ASensorButton)
                in.putExtra("sensorType", Sensor.TYPE_LIGHT);
            else if (v.getId() == R.id.accelButton)
                in.putExtra("sensorType", Sensor.TYPE_ACCELEROMETER);
        }
        startActivity(in);
    }
}
